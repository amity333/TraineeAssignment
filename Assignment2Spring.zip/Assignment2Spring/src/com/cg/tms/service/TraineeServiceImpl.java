package com.cg.tms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;
@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeDao tdao;

	public TraineeDao getTdao() {
		return tdao;
	}

	public void setTdao(TraineeDao tdao) {
		this.tdao = tdao;
	}

	@Override
	public boolean validateTrainee(Login trainee) 
	{
		//System.out.println(trainee.getUserName());
		Login tr=tdao.getTraineeByUserName(trainee.getUserName());
		if (trainee.getUserName().equalsIgnoreCase(tr.getUserName())  && trainee.getUserPass().equalsIgnoreCase(tr.getUserPass()))
		{
			return true;
		} 
		else
			return false;
	}

	@Override
	public Login getTraineeByUserName(String unm) {
		Login log = tdao.getTraineeByUserName(unm);
		return log;
	}

	@Override
	public void addTrainee(Trainee t) {
		System.out.println("inside Ser IMPL");
		tdao.addTrainee(t);
		
	}

	@Override
	public void deleteTrainee(Trainee t) {
		tdao.deleteTrainee(t);
	}

	@Override
	public Trainee getTraineeById(int id) {
		return tdao.getTraineeById(id);
	}

	@Override
	public void updateTrainee(Trainee t) {
		tdao.updateTrainee(t);
	}

	@Override
	public ArrayList<Trainee> getAllTrainee() {
		return tdao.getAllTrainee();
	}

}
