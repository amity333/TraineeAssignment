package com.cg.tms.service;

import java.util.ArrayList;

import com.cg.tms.dto.Login;
import com.cg.tms.dto.Trainee;

public interface TraineeService {
	public boolean validateTrainee(Login trainee);

	public Login getTraineeByUserName(String unm);

	public void addTrainee(Trainee t);

	public void deleteTrainee(Trainee t);

	public Trainee getTraineeById(int id);

	public void updateTrainee(Trainee t);
	
	public ArrayList<Trainee> getAllTrainee();

}
